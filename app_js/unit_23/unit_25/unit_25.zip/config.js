const URL = "https://api.itgid.info";
const APIKEY = "PXkOS3Pdtvs5vOLb";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!
