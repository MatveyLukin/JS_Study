const URL = "https://api.itgid.info";
const APIKEY = "76iVgMEm1cLLDQAW";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!
