const URL = "https://api.itgid.info";
const APIKEY = "ufHEX8xWDbUYiCWm";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!
